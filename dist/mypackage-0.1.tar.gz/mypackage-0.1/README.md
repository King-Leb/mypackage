# mypackage
This library was created as an example of how to create and publish your own python package. Pretty awesome right?

# How to install
...